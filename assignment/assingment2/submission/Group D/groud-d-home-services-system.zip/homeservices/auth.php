<?php
session_start();

include('config.php');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Check if the email and password match a user in the database
    $selectQuery = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($selectQuery);

    if ($result->num_rows == 1) {
        // User found, set session variables and redirect to dashboard or another page
        $user = $result->fetch_assoc();

        $_SESSION["Login"] = "YES";

        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $user["username"];
        $_SESSION["level"] = $user["level"];

        // Redirect to the dashboard or another page
        header("Location: home.php");
        exit();
    } else {
        // Invalid login, display an error message
        $_SESSION["Login"] = "NO";

        echo "Invalid email or password.";
    }
}

// Close the connection
$conn->close();
