<?php
include('checksession.php');
?>
<!DOCTYPE html>

<head>
    <title>Bookings - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/styles.css">

</head>

<body>
    <?php
    include('navbar.php');
    ?>
    <main id="main-doc">

        <?php
        include('config.php');

        // Table names
        $user_id = $_SESSION['user_id'];
        $bookingsTable = "bookings";
        $servicesTable = "services";
        $freelancersTable = "freelancers";

        // Check if the tables exist
        $tablesExist = false;
        $result = $conn->query("SHOW TABLES LIKE '$bookingsTable'");
        if ($result->num_rows > 0) {
            $tablesExist = true;
        }

        if (!$tablesExist) {
            echo "The required tables do not exist.";
        } else {
            if ($_SESSION['level'] == 1) {
                echo '<h1>Manage Bookings</h1>';

                if (isset($_GET['filter'])) {
                    $filter = $_GET['filter'];
                    $selectQuery = "SELECT b.*, s.Service_Name, s.Description, f.Name AS Freelancer_Name
                    FROM $bookingsTable AS b
                    JOIN $servicesTable AS s ON b.Service_ID = s.id
                    JOIN $freelancersTable AS f ON b.Freelancer_ID = '$user_id' WHERE b.Status = '$filter'";
                } else {
                    $selectQuery = "SELECT b.*, s.Service_Name, s.Description, f.Name AS Freelancer_Name
                    FROM $bookingsTable AS b
                    JOIN $servicesTable AS s ON b.Service_ID = s.id
                    JOIN $freelancersTable AS f ON b.Freelancer_ID = '$user_id'";
                }

                $result = $conn->query($selectQuery);

                // Generate the HTML table
                if ($result->num_rows > 0) {
                    echo "<div class='card toolbar' ><div style='flex-grow:1'>" . $result->num_rows . " Records Found.</div>
                <div class=''>Filter: <a href='bookinglist.php'>All</a> | <a href='?filter=Pending'>Pending</a> | <a href='?filter=Confirmed'>Confirmed</a> | <a href='?filter=Completed'>Completed</a> | <a href='?filter=Cancelled'>Cancelled</a></div></div>";


                    echo "<div class='card table'><table id='table'>
                <thead>
                    <tr>
                       
                        <th>Booking Date</th>
                        <th>Booking Time</th>
                        <th>Booking Location</th>
                        <th>Service Name</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>";

                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                    <td>{$row['Booking_Date']}</td>
                    <td>{$row['Booking_Time']}</td>
                    <td>{$row['Booking_Location']}</td>
                    <td>{$row['Service_Name']}</td>
                    <td>{$row['Description']}</td>
                    <td><b>{$row['Status']}</b></td>
                    <td><a href='editbooking.php?bookingid={$row['id']}'>Update Status</a></td>
                </tr>";
                    }

                    echo "</tbody></table></div>";
                } else {
                    echo "<div class='card' style='margin-bottom: 20px; width: auto;'>No Records Found.</div>";
                }
            } else {
                echo '<h1>My Bookings</h1>';
                // Fetch combined data from the tables using JOIN
                if (isset($_GET['filter'])) {
                    $filter = $_GET['filter'];
                    $selectQuery = "SELECT b.*, s.Service_Name, s.Description, f.Name AS Freelancer_Name
                    FROM $bookingsTable AS b
                    JOIN $servicesTable AS s ON b.Service_ID = s.id
                    JOIN $freelancersTable AS f ON b.Freelancer_ID = f.User_ID  WHERE b.Status = '$filter'";
                } else {
                    $selectQuery = "SELECT b.*, s.Service_Name, s.Description, f.Name AS Freelancer_Name
                    FROM $bookingsTable AS b
                    JOIN $servicesTable AS s ON b.Service_ID = s.id
                    JOIN $freelancersTable AS f ON b.Freelancer_ID = f.User_ID";
                }

                $result = $conn->query($selectQuery);

                // Generate the HTML table
                if ($result->num_rows > 0) {
                    echo "<div class='card toolbar' ><div style='flex-grow:1'>" . $result->num_rows . " Records Found.</div>
                <div class=''>Filter: <a href='bookinglist.php'>All</a> | <a href='?filter=Pending'>Pending</a> | <a href='?filter=Confirmed'>Confirmed</a> | <a href='?filter=Completed'>Completed</a> | <a href='?filter=Cancelled'>Cancelled</a></div></div>";


                    echo "<div class='card table'><table id='table'>
                <thead>
                    <tr>
                       
                        <th>Booking Date</th>
                        <th>Booking Time</th>
                        <th>Booking Location</th>
                        <th>Service Name</th>
                        <th>Description</th>
                        <th>Freelancer Name</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>";

                    while ($row = $result->fetch_assoc()) {
                        $actionbtn = $row['Status'] == "Completed" ? "<a href='createreview.php?bookingid={$row['id']}'>Leave Review</a>" : ($row['Status'] == "Cancelled" ? "" : "<a href='cancelbooking.php?bookingid={$row['id']}' style='color:red'>Cancel Booking</a>");
                        echo "<tr>
                    <td>{$row['Booking_Date']}</td>
                    <td>{$row['Booking_Time']}</td>
                    <td>{$row['Booking_Location']}</td>
                    <td>{$row['Service_Name']}</td>
                    <td>{$row['Description']}</td>
                    <td>{$row['Freelancer_Name']}</td>
                    <td><b>{$row['Status']}</b></td>
                    <td>{$actionbtn}</td>
                </tr>";
                    }

                    echo "</tbody></table></div>";
                } else {
                    echo "<div class='card' style='margin-bottom: 20px; width: auto;'>No Records Found.</div>";
                }
            }
        }

        // Close the connection
        $conn->close();
        ?>
    </main>
</body>

</html>