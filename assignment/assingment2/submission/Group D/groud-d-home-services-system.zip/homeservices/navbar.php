<?php

if ($_SESSION['level'] == 1) {
    echo '
    <nav id="navbar">
    <div class="navheader"><div style="display: flex; align-items: center;">
    <img src="img/house-repair.png" width="30px" height="30px" />
    <div style="font-weight: 400; color:#fff; margin-left:20px">Home Services System<br>For Freelancers</div>
</div></div>
    <ul>

        <li><a class="nav-link" href="home.php"><img src="img/dashboard.png" width="14px" height="14px" style="margin-right:18px"/> Dashboard</a></li>
        <li><a class="nav-link" href="serviceslist.php"><img src="img/home-repair.png" width="14px" height="14px" style="margin-right:18px"/> My Services</a></li>
        <li><a class="nav-link" href="bookinglist.php"><img src="img/appointment.png" width="14px" height="14px" style="margin-right:18px"/> Bookings</a></li>
        <li><a class="nav-link" href="logout.php"><img src="img/logout.png" width="14px" height="14px" style="margin-right:18px"/> Logout</a></li>

    </ul>
    </nav>';
} else {
    echo '
    <nav id="navbar">
    <div class="navheader"><div style="display: flex; align-items: center;">
    <img src="img/house-repair.png" width="30px" height="30px" />
    <div style="font-weight: 400; color:#fff; margin-left:20px">Home Services System<br>For Customers</div>
</div></div>
    <ul>

    <li><a class="nav-link" href="home.php"><img src="img/dashboard.png" width="14px" height="14px" style="margin-right:18px"/> Dashboard</a></li>
    <li><a class="nav-link" href="serviceslist.php"><img src="img/home-repair.png" width="14px" height="14px" style="margin-right:18px"/> Home Services</a></li>
    <li><a class="nav-link" href="bookinglist.php"><img src="img/appointment.png" width="14px" height="14px" style="margin-right:18px"/> My Bookings</a></li>
    <li><a class="nav-link" href="review.php"><img src="img/feedback.png" width="14px" height="14px" style="margin-right:18px"/> My Reviews</a></li>
    <li><a class="nav-link" href="logout.php"><img src="img/logout.png" width="14px" height="14px" style="margin-right:18px" />
    Logout</a></li>
       
    </ul>
    </nav>';
}
