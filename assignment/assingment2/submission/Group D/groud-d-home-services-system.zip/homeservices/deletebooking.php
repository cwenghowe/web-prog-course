<?php
session_start();

include('config.php');

// Get the booking ID from the POST request
$bookingID = $_POST["booking_id"];

// Delete the record from the table
$deleteQuery = "DELETE FROM $tableName WHERE id = $bookingID";

if ($conn->query($deleteQuery) === TRUE) {
    echo "Record deleted successfully.";
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
