<?php
include('tables/users_table.php');
include('tables/customers_table.php');
include('tables/freelancers_table.php');
include('tables/bookings_table.php');
include('tables/reviews_table.php');
include('tables/services_table.php');

//include('tables/test_data_users.php');

// Close the connection
$conn->close();
