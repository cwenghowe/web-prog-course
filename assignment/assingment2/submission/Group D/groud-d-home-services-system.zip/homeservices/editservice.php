<?php
include('checksession.php');
?>
<!DOCTYPE html>

<head>
    <title>Edit Service - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/styles.css">

</head>

<body>
    <?php
    include('navbar.php');

    include('config.php');

    $serviceID = $_GET['serviceid'];

    $selectQuery = "SELECT * FROM services WHERE id = $serviceID";
    $result = $conn->query($selectQuery);

    if ($result->num_rows > 0) {
        $booking = $result->fetch_assoc();

        $availableselected = $booking["Availability"] == "available" ? "selected" : "";
        $unavailableselected = $booking["Availability"] == "unavailable" ? "selected" : "";

    ?>
        <main id="main-doc">
            <h1>Edit Service</h1>
            <div class="card" style="width: auto;">
                <form action="updateservice.php" method="POST">
                    <input type="hidden" id="service_id" name="service_id" value="<?php echo $booking["id"]; ?>">
                    <input type="hidden" id="freelancer_id" name="freelancer_id" value="<?php echo $booking["Freelancer_ID"]; ?>">

                    <label for="service_name">Service Name:</label>
                    <input type="text" id="service_name" name="service_name" value="<?php echo $booking["Service_Name"]; ?>" required><br><br>

                    <label for="description">Description:</label><br>
                    <textarea id="description" name="description" rows="10" cols="110" required><?php echo $booking["Description"]; ?></textarea><br><br>

                    <label for="availability">Availability:</label>
                    <select id="availability" name="availability" required>
                        <option value="available" <?php echo $availableselected ?>>Available</option>
                        <option value="unavailable" <?php echo $unavailableselected ?>>Unavailable</option>
                    </select><br><br>

                    <input type="submit" value="Submit">
                </form>
            </div>
        </main>
</body>

</html>
<?php
    } else {
        echo "No service found with ID: " . $serviceID;
    }
    $conn->close();
?>