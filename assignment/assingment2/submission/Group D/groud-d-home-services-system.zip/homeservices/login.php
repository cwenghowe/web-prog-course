<?php
// Start up your PHP Session
session_start();

include('config.php');
include('createtables.php');

?>
<!DOCTYPE html>

<head>
    <title>Login - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/login.css">
</head>

<body>
    <div class="center-div login-main">
        <div>
            <div style="display: flex; align-items: center">
                <img src="img/house-repair.png" width="80px" height="80px" />
                <h1 style="font-weight: 400; color:#fff; margin-left:20px">Welcome to<br>Home Services System</h1>
            </div>
            <div class="card login credential" style="margin-bottom: 20px;">
                <div>
                    <p>Login as <em>Customer</em></p>
                    <p>Username: customer1<br>Password: abcd1234</p>
                </div>
                <div>
                    <p>Login as <em>Freelancer</em></p>
                    <p>Username: freelancer1<br>Password: abcd1234</p>
                </div>
            </div>
        </div>
    </div>
    <div class="center-div">

        <div class="card login">
            <h1>Login</h1>
            <form method="post" action="auth.php">
                <input type="text" name="username" placeholder="Enter your User Name" required />
                <input type="password" name="password" placeholder="Enter your Password" required />
                <input type="submit" value="Login" />
            </form>
        </div>
    </div>
</body>

</html>