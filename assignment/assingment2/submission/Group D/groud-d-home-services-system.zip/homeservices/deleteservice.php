<?php
include('config.php');

// Table name
$tableName = "services";

// Check if the table exists
$tableExists = false;
$result = $conn->query("SHOW TABLES LIKE '$tableName'");
if ($result->num_rows > 0) {
    $tableExists = true;
}

// If the table doesn't exist, display an error message
if (!$tableExists) {
    echo "The 'services' table does not exist.";
} else {
    // Check if the request is a POST request
    if ($_SERVER["REQUEST_METHOD"] === "GET") {
        // Get the service ID from the POST request
        $serviceID = $_GET["serviceid"];

        // Delete the record from the table
        $deleteQuery = "DELETE FROM $tableName WHERE id = $serviceID";

        if ($conn->query($deleteQuery) === TRUE) {
            header("Location: success.php?type=delete");
            exit();
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "Invalid request method.";
    }
}

// Close the connection
$conn->close();
