<?php
include('checksession.php');
?>
<!DOCTYPE html>

<head>
    <title>Create Service - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/styles.css">

</head>

<body>
    <?php
    include('navbar.php');
    ?>
    <main id="main-doc">
        <h1>Create New Service</h1>
        <div class="card" style="width: auto;">
            <form action="insertservice.php" method="POST">

                <label for="service_name">Service Name:</label>
                <input type="text" id="service_name" name="service_name" required><br><br>

                <label for="description">Description:</label><br>
                <textarea id="description" name="description" rows="10" cols="110" required></textarea><br><br>

                <label for="availability">Availability:</label>
                <select id="availability" name="availability" required>
                    <option value="available">Available</option>
                    <option value="unavailable">Unavailable</option>
                </select><br><br>

                <input type="submit" value="Submit">
            </form>
        </div>
    </main>
</body>

</html>