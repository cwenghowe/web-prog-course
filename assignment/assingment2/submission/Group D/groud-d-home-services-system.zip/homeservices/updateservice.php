
<?php
include('config.php');

// Table name
$tableName = "services";

// Check if the table exists
$tableExists = false;
$result = $conn->query("SHOW TABLES LIKE '$tableName'");
if ($result->num_rows > 0) {
    $tableExists = true;
}

// If the table doesn't exist, display an error message
if (!$tableExists) {
    echo "The 'services' table does not exist.";
} else {
    // Check if the request is a POST request
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Get the service ID and updated values from the POST request
        $serviceID = $_POST["service_id"];
        $freelancerID = $_POST["freelancer_id"];
        $serviceName = $_POST["service_name"];
        $description = $_POST["description"];
        $availability = $_POST["availability"];

        // Update the record in the table
        $updateQuery = "UPDATE $tableName SET Freelancer_ID = '$freelancerID', Service_Name = '$serviceName',
                        Description = '$description', Availability = '$availability' WHERE id = $serviceID";

        if ($conn->query($updateQuery) === TRUE) {
            header("Location: success.php?type=service");
            exit();
        } else {
            echo "Error updating record: " . $conn->error;
        }
    } else {
        echo "Invalid request method.";
    }
}

// Close the connection
$conn->close();
