
<?php
session_start();
include('config.php');

// Table name
$tableName = "reviews";

// Check if the table exists
$tableExists = false;
$result = $conn->query("SHOW TABLES LIKE '$tableName'");
if ($result->num_rows > 0) {
    $tableExists = true;
}

// If the table doesn't exist, display an error message
if (!$tableExists) {
    echo "The 'services' table does not exist.";
} else {
    // Check if the request is a POST request
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Prepare the data from the POST request
        $customerID = $_SESSION['user_id'];
        $booking_id = $_POST["booking_id"];
        $comment = $_POST["comment"];
        $rating = $_POST["rating"];
        $reviewdt = date("Y-m-d H:i:s");


        // Insert the data into the table
        $insertQuery = "INSERT INTO $tableName (Booking_ID, Comment, Rating, Update_DateTime, Customer_ID)
                        VALUES ('$booking_id', '$comment', '$rating', '$reviewdt', '$customerID')";

        if ($conn->query($insertQuery) === TRUE) {
            header("Location: success.php?type=service");
            exit();
        } else {
            echo "Error inserting data: " . $conn->error;
        }
    } else {
        echo "Invalid request method.";
    }
}

// Close the connection
$conn->close();
