<?php
include('checksession.php');
?>
<!DOCTYPE html>

<head>
    <title>Services - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/styles.css">

</head>

<body>
    <?php
    include('navbar.php');
    ?>
    <main id="main-doc">

        <?php
        if ($_SESSION['level'] == 1) {
            echo '<h1>My Services</h1>';
        }
        ?>
        <?php
        include('config.php');
        // Table names
        $servicesTable = "services";
        $freelancersTable = "freelancers";

        // Check if the tables exist
        $tablesExist = false;
        $result = $conn->query("SHOW TABLES LIKE '$servicesTable'");
        if ($result->num_rows > 0) {
            $tablesExist = true;
        }

        if (!$tablesExist) {
            echo "The required tables do not exist.";
        } else {
            if ($_SESSION['level'] == 1) {


                $user_id = $_SESSION['user_id'];
                // Fetch combined data from the tables using JOIN


                if (isset($_GET['filter'])) {
                    $filter = $_GET['filter'];
                    $selectQuery = "SELECT * FROM $servicesTable WHERE Freelancer_ID = $user_id AND Availability = '$filter'";
                } else {
                    $selectQuery = "SELECT * FROM $servicesTable WHERE Freelancer_ID = $user_id";
                }

                $result = $conn->query($selectQuery);

                // Generate the HTML table
                if ($result->num_rows > 0) {

                    echo "<div class='card toolbar' ><div style='flex-grow:1'><a href='createservice.php' class='linkbutton'>+ Create New Service</a></div>
                    <div class=''><b>" . $result->num_rows . " Record Found.</b> Filter: <a href='serviceslist.php'>All</a> | <a href='?filter=available'>Available</a> | <a href='?filter=unavailable'>Unavailable</a></div></div>";

                    echo "
                    <div class='card table'>
                    <table id='table'>
                <thead>
                    <tr>
                        <th>Service Name</th>
                        <th>Description</th>
                        <th>Availability</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>";

                    while ($row = $result->fetch_assoc()) {
                        $statuscolor = $row['Availability'] == "available" ? "green" : "red";

                        echo "<tr>
                    <td>{$row['Service_Name']}</td>
                    <td>{$row['Description']}</td>
                    <td><b style='color:{$statuscolor}'>{$row['Availability']}</b></td>
                    <td ><a href='editservice.php?serviceid={$row['id']}'>Edit</a><br><br><a href='deleteservice.php?serviceid={$row['id']}'>Delete</a></td>
                </tr>";
                    }

                    echo "</tbody></table></div>";
                } else {
                    echo "<div class='card' style='margin-bottom: 20px; width: auto;'>No Records Found.</div>";
                }
            } else {
                // Fetch combined data from the tables using JOIN
                echo '<h1>Services</h1>';
                if (isset($_GET['filter'])) {
                    $filter = $_GET['filter'];
                    $selectQuery1 = "SELECT s.*, f.Name AS Freelancer_Name
                    FROM $servicesTable AS s
                    JOIN $freelancersTable AS f ON s.Freelancer_ID = f.User_ID WHERE s.Availability = '$filter' ";
                } else {
                    $selectQuery1 = "SELECT s.*, f.Name AS Freelancer_Name
                    FROM $servicesTable AS s
                    JOIN $freelancersTable AS f ON s.Freelancer_ID = f.User_ID";
                }


                $result1 = $conn->query($selectQuery1);

                // Generate the HTML table
                if ($result1->num_rows > 0) {

                    echo "<div class='card toolbar' ><div style='flex-grow:1'>" . $result1->num_rows . " Services Found.</div>
                    <div class=''>Filter: <a href='serviceslist.php'>All</a> | <a href='?filter=available'>Available</a> | <a href='?filter=unavailable'>Unavailable</a></div></div>";

                    while ($row = $result1->fetch_assoc()) {

                        $statuscolor = $row['Availability'] == "available" ? "green" : "red";

                        echo "
                        <div class='card services services-card'>
                        <div class='services-thumb'></div>
                        <div class='service-desc'>
                <h3>{$row['Service_Name']} by {$row['Freelancer_Name']}</h3>
                <b style='color:{$statuscolor}'>{$row['Availability']}</b>
                <p>{$row['Description']}</p>
                <a href='createbooking.php?serviceid={$row['id']}&freelancerid={$row['Freelancer_ID']}' class='linkbutton float-right'>Book Now</a>
                </div>
                </div>";
                    }
                } else {
                    echo "<div class='card' style='margin-bottom: 20px; width: auto;'>No Records Found.</div>";
                }
            }
        }

        // Close the connection
        $conn->close(); ?>
    </main>
</body>

</html>