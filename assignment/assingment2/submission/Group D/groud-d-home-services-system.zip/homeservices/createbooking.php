<?php
include('checksession.php');
?>
<!DOCTYPE html>

<head>
    <title>Book Service - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/styles.css">

</head>

<body>
    <?php
    include('navbar.php'); ?>
    <main id="main-doc">
        <h1>Book Service</h1>
        <?php
        include('config.php');
        // Table names
        $servicesTable = "services";
        $freelancersTable = "freelancers";

        $service_id = $_GET['serviceid'];
        $freelancer_id = $_GET['freelancerid'];

        $selectQuery = "SELECT s.*, f.Name AS Freelancer_Name
    FROM $servicesTable AS s
    JOIN $freelancersTable AS f ON s.Freelancer_ID = f.User_ID WHERE s.id = '$service_id' ";
        $result = $conn->query($selectQuery);

        // Generate the HTML table
        if ($result->num_rows > 0) {

            while ($row = $result->fetch_assoc()) {

                echo "
                        <div class='card services services-card'>
                        <div class='services-thumb'></div>
                        <div class='service-desc'>
                <h3>{$row['Service_Name']} by {$row['Freelancer_Name']}</h3>
                <b>{$row['Availability']}</b>
                <p>{$row['Description']}</p>
                </div>
                </div>";
            }
        }
        ?>

        <div class="card" style="width: auto;">
            <h2 style="font-weight: 400; margin-bottom: 30px ">Complete Booking Details.</h2>

            <form action="insertbooking.php" method="POST">
                <input type="hidden" id="freelancer_id" name="freelancer_id" value="<?php echo $freelancer_id; ?>">
                <input type="hidden" id="service_id" name="service_id" value="<?php echo $service_id; ?>">

                <label for="booking_date">Booking Date:</label>
                <input type="date" id="booking_date" name="booking_date" required><br><br>

                <label for="booking_time">Booking Time:</label>
                <input type="time" id="booking_time" name="booking_time" required><br><br>

                <label for="booking_location">Booking Location:</label>
                <input type="text" id="booking_location" name="booking_location" required><br><br>

                <input type="hidden" id="status" name="status" value="Pending" />

                <input type="submit" value="Submit">
            </form>
        </div>
    </main>
</body>

</html>
<?php
$conn->close();
?>