<?php
include('checksession.php');
?>
<!DOCTYPE html>

<head>
    <title>Update Booking - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/styles.css">

</head>

<body>
    <?php
    include('navbar.php');

    include('config.php');
    if ($_SESSION['level'] == 1) {
        $bookingID = $_GET['bookingid'];

        $selectQuery = "SELECT * FROM bookings WHERE id = $bookingID";
        $result = $conn->query($selectQuery);

        if ($result->num_rows > 0) {
            $booking = $result->fetch_assoc();

            $pendingselected = $booking["Status"] == "Pending" ? "selected" : "";
            $confirmedselected = $booking["Status"] == "Confirmed" ? "selected" : "";
            $completedselected = $booking["Status"] == "Completed" ? "selected" : "";
            $cancelledselected = $booking["Status"] == "Cancelled" ? "selected" : "";

    ?>
            <main id="main-doc">
                <h1>Update Booking Status</h1>
                <?php

                echo "
            <div class='card services'>
            <div class=''>
    <b>Booking ID #{$booking['id']}</b>
    <p>Date: {$booking['Booking_Date']}<br>
    Time: {$booking['Booking_Time']}<br>
    Location: {$booking['Booking_Location']}<br>
    
    </div>
    </div>"; ?>
                <div class="card" style="width: auto;">
                    <h2 style='font-weight: 400; margin-bottom: 30px '>Update Booking Status</h2>

                    <form action="updatebooking.php" method="POST">
                        <input type="hidden" id="booking_id" name="booking_id" value="<?php echo $booking["id"]; ?>">

                        <label for="status">Status:</label>
                        <select id="status" name="status" required>
                            <option value="Pending" <?php echo $pendingselected ?>>Pending</option>
                            <option value="Confirmed" <?php echo $confirmedselected ?>>Confirmed</option>
                            <option value="Completed" <?php echo $completedselected ?>>Completed</option>
                            <option value="Cancelled" <?php echo $cancelledselected ?>>Cancelled</option>
                        </select><br><br>

                        <input type="submit" value="Submit">
                    </form>
                </div>
            </main>
</body>

</html>
<?php
        } else {
            echo "No booking found with ID: " . $bookingID;
        }
    }
    $conn->close();
?>