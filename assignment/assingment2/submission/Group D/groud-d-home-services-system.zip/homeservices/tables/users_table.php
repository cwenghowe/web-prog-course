<?php
//USERS
// Table name to check and create
$users_tableName = "users";

// Check if the table exists
$users_tableExists = false;
$users_table_result = $conn->query("SHOW TABLES LIKE '$users_tableName'");
if ($users_table_result->num_rows > 0) {
    $users_tableExists = true;
}

// If the table doesn't exist, create a new table
if (!$users_tableExists) {
    $createUsersTableQuery = "CREATE TABLE $users_tableName (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(30) NOT NULL,
        password VARCHAR(30) NOT NULL,
        level INT(6) NOT NULL
    )";

    if ($conn->query($createUsersTableQuery) === TRUE) {
        echo "Table " . $users_tableName . " created successfully.";
    } else {
        echo "Error creating table " . $users_tableName . ": " . $conn->error;
    }
} else {
}
