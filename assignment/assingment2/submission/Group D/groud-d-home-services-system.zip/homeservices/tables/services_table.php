<?php
// Table name
$tableName = "services";

// Check if the table exists
$tableExists = false;
$result = $conn->query("SHOW TABLES LIKE '$tableName'");
if ($result->num_rows > 0) {
    $tableExists = true;
}

// If the table doesn't exist, create it
if (!$tableExists) {
    $createTableQuery = "CREATE TABLE $tableName (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        Freelancer_ID INT(6) UNSIGNED NOT NULL,
        Service_Name VARCHAR(100) NOT NULL,
        Description TEXT NOT NULL,
        Availability VARCHAR(50) NOT NULL
    )";

    if ($conn->query($createTableQuery) === TRUE) {
        echo "Table " . $tableName . " created successfully.";
    } else {
        echo "Error creating table " . $tableName . ": " . $conn->error;
    }
} else {
}
