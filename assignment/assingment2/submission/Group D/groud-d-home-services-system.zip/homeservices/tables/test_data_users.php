<?php
//Uncomment to insert test user data
// $insertQuery = "INSERT INTO $users_tableName (username, password, level)
//                 VALUES ('Customer 1', 'abcd123@', 0)";
// $conn->query($insertQuery);
// $insertQuery1 = "INSERT INTO $users_tableName (username, password, level)
//                 VALUES ('Freelance 1', 'abcd123@', 1)";
// $conn->query($insertQuery1);
