<?php
// Table name
$tableName = "freelancers";

// Check if the table exists
$tableExists = false;
$result = $conn->query("SHOW TABLES LIKE '$tableName'");
if ($result->num_rows > 0) {
    $tableExists = true;
}

// If the table doesn't exist, create it
if (!$tableExists) {
    $createTableQuery = "CREATE TABLE $tableName (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        User_ID INT(6) NOT NULL,
        Name VARCHAR(100) NOT NULL,
        Email VARCHAR(100) NOT NULL,
        Phone_Number VARCHAR(20) NOT NULL,
        Address VARCHAR(255) NOT NULL,
        Service_Description TEXT NOT NULL,
        Availability VARCHAR(50) NOT NULL
    )";

    if ($conn->query($createTableQuery) === TRUE) {
        echo "Table " . $tableName . " created successfully.";
    } else {
        echo "Error creating table " . $tableName . ": " . $conn->error;
    }
} else {
}
