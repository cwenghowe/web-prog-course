<?php
//CUSTOMERS
// Table name
$customers_tableName = "customers";

// Check if the table exists
$customers_tableExists = false;
$customers_result = $conn->query("SHOW TABLES LIKE '$customers_tableName'");
if ($customers_result->num_rows > 0) {
    $customers_tableExists = true;
}

// If the table doesn't exist, create it
if (!$customers_tableExists) {
    $createCustomersTableQuery = "CREATE TABLE $customers_tableName (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        User_ID INT(6) NOT NULL,
        First_Name VARCHAR(50) NOT NULL,
        Last_Name VARCHAR(50) NOT NULL,
        Email VARCHAR(100) NOT NULL,
        Phone_Number VARCHAR(20) NOT NULL,
        Address VARCHAR(255) NOT NULL
    )";

    if ($conn->query($createCustomersTableQuery) === TRUE) {
        echo "Table " . $customers_tableName . " created successfully.";
    } else {
        echo "Error creating table " . $customers_tableName . ": " . $conn->error;
    }
} else {
}
