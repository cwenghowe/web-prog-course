<?php
// Table name
$tableName = "reviews";

// Check if the table exists
$tableExists = false;
$result = $conn->query("SHOW TABLES LIKE '$tableName'");
if ($result->num_rows > 0) {
    $tableExists = true;
}

// If the table doesn't exist, create it
if (!$tableExists) {
    $createTableQuery = "CREATE TABLE $tableName (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        Customer_ID INT(6) UNSIGNED NOT NULL,
        Booking_ID INT(6) UNSIGNED NOT NULL,
        Comment TEXT NOT NULL,
        Rating INT(1) NOT NULL,
        Update_DateTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";

    if ($conn->query($createTableQuery) === TRUE) {
        echo "Table " . $tableName . " created successfully.";
    } else {
        echo "Error creating table " . $tableName . ": " . $conn->error;
    }
} else {
}
