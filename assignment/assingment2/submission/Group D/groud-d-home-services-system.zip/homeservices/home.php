<?php
include('checksession.php');
?>
<!DOCTYPE html>

<head>
    <title>Home - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/styles.css">

</head>

<body>
    <?php
    include('navbar.php');
    ?>
    <main id="main-doc">
        <h1>Dashboard</h1>

        <div class="dashboard-grid">
            <div class="dashboard-header card dashboard-item">
                <div>
                    <h4>Welcome to<br>Home Services Portal</h4>
                    <h1 style="font-weight: 400; ">Hi, <?php echo $_SESSION['username'] ?></h1>
                    You are logged in as <em><?php
                                                if ($_SESSION['level'] == 1) {
                                                    echo 'Freelancer';
                                                } else {
                                                    echo 'Customer';
                                                }
                                                ?></em>
                </div>
                <div>
                    <img src="img/user.png" width="80px" height="80px" />
                </div>
            </div>

            <?php

            if ($_SESSION['level'] == 1) {

            ?>
                <div class="card dashboard-item" width="100%">
                    <div>
                        <h1 style="font-weight: 400; ">Manage Services</h1>
                        <p>Create service, update or delete your offered services.</p>
                        <a href="serviceslist.php">Open My Services</a>
                    </div>
                    <div>
                        <img src="img/house.png" width="80px" height="80px" />
                    </div>
                </div>
                <div class="card dashboard-item ">
                    <div>
                        <h1 style="font-weight: 400; ">Manage Bookings</h1>
                        <p>Update status of booked services.</p>
                        <a href="bookinglist.php">Manage Booking</a>
                    </div>
                    <div>
                        <img src="img/event.png" width="80px" height="80px" />
                    </div>
                </div>

            <?php
            } else {
            ?>


                <div class="card dashboard-item ">
                    <div>
                        <h1 style="font-weight: 400; ">Manage Booking</h1>
                        <p>Keep updated to the status of your booking.</p>
                        <a href="bookinglist.php">Manage Booking</a>
                    </div>
                    <div>
                        <img src="img/event.png" width="80px" height="80px" />
                    </div>
                </div>
                <div class="card dashboard-item" width="100%">
                    <div>
                        <h1 style="font-weight: 400; ">Home Services</h1>
                        <p>Book home services offered by freelancers near you.</p>
                        <a href="serviceslist.php">Open Home Services</a>
                    </div>
                    <div>
                        <img src="img/house.png" width="80px" height="80px" />
                    </div>
                </div>

            <?php
            }
            ?>

        </div>
    </main>
</body>

</html>