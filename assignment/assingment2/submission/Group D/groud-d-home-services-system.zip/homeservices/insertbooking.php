<?php
session_start();

include('config.php');

// Prepare the data from the POST request
$customerID = $_SESSION['user_id'];
$freelancerID = $_POST["freelancer_id"];
$serviceID = $_POST["service_id"];
$bookingDate = $_POST["booking_date"];
$bookingTime = $_POST["booking_time"];
$bookingLocation = $_POST["booking_location"];
$status = $_POST["status"];

// Insert the data into the table
$insertQuery = "INSERT INTO bookings (Customer_ID, Freelancer_ID, Service_ID, Booking_Date, Booking_Time, Booking_Location, Status)
                 VALUES ('$customerID', '$freelancerID', '$serviceID', '$bookingDate', '$bookingTime', '$bookingLocation', '$status')";

if ($conn->query($insertQuery) === TRUE) {
    // Redirect success page
    header("Location: success.php?type=booking");
    exit();
} else {
    echo "Error inserting data: " . $conn->error;
}

$conn->close();
