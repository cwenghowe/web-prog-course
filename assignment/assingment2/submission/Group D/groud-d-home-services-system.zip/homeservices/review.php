<?php
include('checksession.php');
?>
<!DOCTYPE html>

<head>
    <title>My Reviews - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/styles.css">

</head>

<body>
    <?php
    include('navbar.php');
    ?>
    <main id="main-doc">
        <h1>My Reviews</h1>

        <?php
        include('config.php');

        // Table name
        $tableName = "reviews";

        // Check if the table exists
        $tableExists = false;
        $result = $conn->query("SHOW TABLES LIKE '$tableName'");
        if ($result->num_rows > 0) {
            $tableExists = true;
        }

        // If the table doesn't exist, display an error message
        if (!$tableExists) {
            echo "The 'reviews' table does not exist.";
        } else {
            $user_id = $_SESSION['user_id'];
            $selectQuery = "SELECT * FROM $tableName WHERE Customer_ID = $user_id";
            $result = $conn->query($selectQuery);

            // Generate the HTML table
            if ($result->num_rows > 0) {

                echo "<div class='card toolbar' ><div style='flex-grow:1'>" . $result->num_rows . " Records Found.</div></div>";
                echo "<div class='card table'><table id='table'>
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Comment</th>
                        <th>Rating</th>
                        <th>Reviewed on</th>
                    </tr>
                </thead>
                <tbody>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                    <td>Booking #{$row['Booking_ID']}</td>
                    <td>{$row['Comment']}</td>
                    <td>{$row['Rating']}</td>
                    <td>{$row['Update_DateTime']}</td>
                </tr>";
                }

                echo "</tbody></table></div>";
            } else {
                echo "<div class='card' style='margin-bottom: 20px; width: auto;'>No Records Found.</div>";
            }
        }

        // Close the connection
        $conn->close();
        ?>
    </main>
</body>

</html>