const stars = Array.from(document.querySelectorAll(".star__item"));
const user_selected_star = document.querySelector("#user-selected-star");
const message = document.querySelector(".star__message");

stars.forEach((star) => {
  // Mouseover event
  star.addEventListener("mouseover", (e) => {
    stars.forEach((item, current_index) => {
      if (
        current_index <= stars.indexOf(e.target) ||
        item.classList.contains("is-selected")
      ) {
        item.classList.add("is-selected");
      } else {
        item.classList.remove("is-selected");
      }
    });
  });

  // Mouseover event
  star.addEventListener("mouseleave", (e) => {
    stars.forEach((item, current_index) => {
      item.classList.remove("is-selected");

      if (current_index < user_selected_star.value) {
        item.classList.add("is-selected");
      }
    });
  });

  // Click event
  star.addEventListener("click", (e) => {
    const selected_index = stars.indexOf(e.target);
    let message_template;

    user_selected_star.value = selected_index + 1;

    if (user_selected_star.value > 1) {
      message_template = `Thanks! You rated this ${user_selected_star.value} stars.`;
    } else {
      message_template = `We will improve ourselves. You rated this ${user_selected_star.value} star.`;
    }

    message.innerHTML = message_template;
  });
});
