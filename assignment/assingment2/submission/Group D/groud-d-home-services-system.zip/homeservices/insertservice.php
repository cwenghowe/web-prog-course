
<?php
session_start();
include('config.php');

// Table name
$tableName = "services";

// Check if the table exists
$tableExists = false;
$result = $conn->query("SHOW TABLES LIKE '$tableName'");
if ($result->num_rows > 0) {
    $tableExists = true;
}

// If the table doesn't exist, display an error message
if (!$tableExists) {
    echo "The 'services' table does not exist.";
} else {
    // Check if the request is a POST request
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Prepare the data from the POST request
        $freelancerID = $_SESSION['user_id'];
        $serviceName = $_POST["service_name"];
        $description = $_POST["description"];
        $availability = $_POST["availability"];

        // Insert the data into the table
        $insertQuery = "INSERT INTO $tableName (Freelancer_ID, Service_Name, Description, Availability)
                        VALUES ('$freelancerID', '$serviceName', '$description', '$availability')";

        if ($conn->query($insertQuery) === TRUE) {
            header("Location: success.php?type=service");
            exit();
        } else {
            echo "Error inserting data: " . $conn->error;
        }
    } else {
        echo "Invalid request method.";
    }
}

// Close the connection
$conn->close();
