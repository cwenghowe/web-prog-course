<?php
session_start();

include('config.php');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the booking ID and updated values from the POST request
    $bookingID = $_POST["booking_id"];
    $status = $_POST["status"];

    // Update the record in the table
    $updateQuery = "UPDATE bookings SET Status = '$status' WHERE id = $bookingID";

    if ($conn->query($updateQuery) === TRUE) {
        header("Location: success.php?type=updatebooking");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    echo "Invalid request method.";
}

$conn->close();
