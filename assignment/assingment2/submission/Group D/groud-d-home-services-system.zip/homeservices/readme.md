 <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->

1. Run sql db dump : dump-homeservices_db-202307120051.sql
2. Edit config.php for db connection
3. Login as Customer, username: customer1 | password: abcd1234
4. Login as Freelancer, username: freelancer1 | password: abcd1234
