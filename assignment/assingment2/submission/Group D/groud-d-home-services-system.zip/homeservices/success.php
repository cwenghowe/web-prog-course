<?php
include('checksession.php');
?>
<!DOCTYPE html>

<head>
    <title>Success - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/styles.css">

</head>

<body>
    <?php
    include('navbar.php'); ?>
    <main id="main-doc">
        <div class="center-div">

            <div class="card success">
                <img src="img/success.png" width="80px" height="80px" style="margin-bottom: 50px" />
                <h1>Success</h1>
                <p>Process succesfully submitted.</p>
                <a href="home.php">Back to Home</a>
            </div>
        </div>
    </main>
</body>

</html>