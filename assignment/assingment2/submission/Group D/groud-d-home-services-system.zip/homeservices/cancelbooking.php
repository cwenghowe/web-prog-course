<?php
session_start();

include('config.php');

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    // Get the booking ID and updated values from the POST request
    $bookingID = $_GET["bookingid"];

    // Update the record in the table
    $updateQuery = "UPDATE bookings SET Status = 'Cancelled' WHERE id = $bookingID";

    if ($conn->query($updateQuery) === TRUE) {
        // Redirect success page
        header("Location: success.php?type=cancelbooking");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
} else {
    echo "Invalid request method.";
}

$conn->close();
