<?php
include('checksession.php');
?>
<!DOCTYPE html>

<head>
    <title>Leave A Review - Home Services Portal</title>
    <!--
Assignment 2: Home Services System
Group:
1. Name: Muhammad Farhan Bin Mohd Izhar, Matrix No: SX212313ECJHF03, Github ID: swazde
2. Name: Muhammad Syafiq bin Mohd Zafri, Matrix No: SX211667ECJHF03, Github ID: SyafiqZafri
3. Name: Muhammad Hizwan Bin Zameri, Matrix No: SX211682ECJHF03, Github ID: hizwanzameri
-->
    <link rel="stylesheet" href="css/styles.css">

</head>

<body>
    <?php
    include('navbar.php'); ?>
    <main id="main-doc">
        <h1>Leave A Review</h1>
        <?php
        include('config.php');
        // Table names
        $bookingsTable = "bookings";
        $servicesTable = "services";
        $freelancersTable = "freelancers";

        $booking_id = $_GET['bookingid'];

        $selectQuery = "SELECT b.*, s.Service_Name, s.Description, f.Name AS Freelancer_Name
        FROM $bookingsTable AS b
        JOIN $servicesTable AS s ON b.Service_ID = s.id
        JOIN $freelancersTable AS f ON b.Freelancer_ID = f.User_ID WHERE b.id = '$booking_id'";
        $result = $conn->query($selectQuery);

        // Generate the HTML table
        if ($result->num_rows > 0) {

            while ($row = $result->fetch_assoc()) {

                echo "
                        <div class='card services'>
                        <h2 style='font-weight: 400; margin-bottom: 30px '>Your Booking</h2>
                        <div class=''>
                <b>Booking ID #{$row['id']}</b>
                <p>Date: {$row['Booking_Date']}<br>
                Time: {$row['Booking_Time']}<br>
                Location: {$row['Booking_Location']}<br>
                Service: {$row['Service_Name']}<br>
                Service Provider: {$row['Freelancer_Name']}</p>

                </div>
                </div>";
            }
        }
        ?>

        <div class="card" style="width: auto;">
            <h2 style="font-weight: 400; margin-bottom: 30px ">Share a Review and Leave a Rating</h2>

            <form action="insertreview.php" method="POST">
                <input type="hidden" id="booking_id" name="booking_id" value="<?php echo $booking_id; ?>">

                <label for="comment">Comment:</label><br>
                <textarea id="comment" name="comment" rows="10" cols="110" required></textarea><br><br>

                <label for="rating">Rating:</label>
                <div class="star">
                    <ul class="star__list">
                        <li class="star__item"></li>
                        <li class="star__item"></li>
                        <li class="star__item"></li>
                        <li class="star__item"></li>
                        <li class="star__item"></li>
                    </ul>
                    <p class="star__message"></p>
                </div>

                <input type="hidden" id="user-selected-star" value="" name="rating">

                <input type="submit" value="Submit">
            </form>
        </div>
    </main>
</body>
<script src="js/starrating.js"></script>

</html>
<?php
$conn->close();
?>