For User
Login Details for user:
Username : test@gmail.com
Password: Test@123

For Admin Panel
Login Details for admin :
Username: admin
Password: Test@12345