<div id="sidebar">
	<ul id = "menu" class = "nav menu">
		<li><a href = "home.php"><i class = "glyphicon glyphicon-home"></i> Dashboard</a></li>
		<li><a href = ""><i class = "glyphicon glyphicon-user"></i> Accounts</a>
			<ul>
				<li><a href = "user.php"><i class = "glyphicon glyphicon-user"></i> Users</a></li>
				<li><a href = "student.php"><i class = "glyphicon glyphicon-user"></i> Students</a></li>
			</ul>
		</li>
	</ul>
</div>